import os
import uuid
import json
from functools import wraps
from datetime import date, timedelta

from flask import Flask, jsonify, request, render_template, session, redirect, url_for, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import mysql.connector

app = Flask(__name__)
app.secret_key = os.environ.get("TASKFLOW_SECRET", "dev-secret-change-me")

UPLOAD_FOLDER = os.path.join(app.root_path, "static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024  # 8MB per upload

# XAMPP MySQL default settings
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "task_manager_db"
}


def get_db_connection():
    return mysql.connector.connect(**db_config)


def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            done BOOLEAN DEFAULT FALSE,
            priority VARCHAR(10) DEFAULT 'medium',
            category VARCHAR(50) DEFAULT 'General',
            due_date DATE NULL,
            notes TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS subtasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            task_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            done BOOLEAN DEFAULT FALSE,
            sort_order INT DEFAULT 0,
            FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attachments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            task_id INT NOT NULL,
            original_name VARCHAR(255) NOT NULL,
            stored_name VARCHAR(255) NOT NULL,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
        )
    """)
    conn.commit()

    # If the tasks table already existed from an earlier version, add any missing columns
    for ddl in [
        "ALTER TABLE tasks ADD COLUMN priority VARCHAR(10) DEFAULT 'medium'",
        "ALTER TABLE tasks ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
        "ALTER TABLE tasks ADD COLUMN category VARCHAR(50) DEFAULT 'General'",
        "ALTER TABLE tasks ADD COLUMN due_date DATE NULL",
        "ALTER TABLE tasks ADD COLUMN notes TEXT NULL",
        "ALTER TABLE tasks ADD COLUMN created_by INT NULL",
        "ALTER TABLE tasks ADD COLUMN assigned_to INT NULL",
        "ALTER TABLE tasks ADD COLUMN completed_at TIMESTAMP NULL",
        "ALTER TABLE tasks ADD COLUMN sort_order INT DEFAULT 0",
        "ALTER TABLE tasks ADD COLUMN repeat_type VARCHAR(10) DEFAULT 'none'",
    ]:
        try:
            cursor.execute(ddl)
            conn.commit()
        except mysql.connector.Error:
            pass  # column already exists

    cursor.close()
    conn.close()


# ---------------------------------------------------------------- auth utils

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            if request.path.startswith("/api/"):
                return jsonify({"error": "Not logged in"}), 401
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")

    data = request.form
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    if not username or not password:
        return render_template("register.html", error="Username and password are required.")

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO users (username, password_hash) VALUES (%s, %s)",
            (username, generate_password_hash(password))
        )
        conn.commit()
        user_id = cursor.lastrowid
    except mysql.connector.IntegrityError:
        cursor.close()
        conn.close()
        return render_template("register.html", error="That username is already taken.")
    cursor.close()
    conn.close()

    session["user_id"] = user_id
    session["username"] = username
    return redirect(url_for("home"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    data = request.form
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()

    if not user or not check_password_hash(user["password_hash"], password):
        return render_template("login.html", error="Invalid username or password.")

    session["user_id"] = user["id"]
    session["username"] = user["username"]
    return redirect(url_for("home"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------- helpers

def _serialize(tasks):
    for t in tasks:
        if t.get("created_at") is not None:
            t["created_at"] = str(t["created_at"])
        if t.get("due_date") is not None:
            t["due_date"] = str(t["due_date"])
        if t.get("completed_at") is not None:
            t["completed_at"] = str(t["completed_at"])
    return tasks


def _clean_priority(value):
    return value if value in ("low", "medium", "high") else "medium"


def _clean_repeat(value):
    return value if value in ("none", "daily", "weekly", "monthly") else "none"


def _next_due_date(due_date, repeat_type):
    if not due_date:
        return None
    if isinstance(due_date, str):
        y, m, d = [int(x) for x in due_date.split("-")]
        due_date = date(y, m, d)
    if repeat_type == "daily":
        return due_date + timedelta(days=1)
    if repeat_type == "weekly":
        return due_date + timedelta(days=7)
    if repeat_type == "monthly":
        month = due_date.month + 1
        year = due_date.year + (1 if month > 12 else 0)
        month = 1 if month > 12 else month
        day = min(due_date.day, 28)
        return date(year, month, day)
    return None


def _usernames_map(cursor):
    cursor.execute("SELECT id, username FROM users")
    return {row["id"]: row["username"] for row in cursor.fetchall()}


# ---------------------------------------------------------------- pages

@app.route('/')
@login_required
def home():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id, username FROM users ORDER BY username")
    users = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('index.html', username=session.get("username"),
                            session_user_id=session.get("user_id"), users=users,
                            users_json=json.dumps(users))


@app.route('/manifest.json')
def manifest():
    return send_from_directory(os.path.join(app.root_path, "static"), "manifest.json")


@app.route('/service-worker.js')
def service_worker():
    return send_from_directory(os.path.join(app.root_path, "static"), "service-worker.js")


# ---------------------------------------------------------------- task API

@app.route('/api/tasks', methods=['GET'])
@login_required
def get_tasks():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM tasks ORDER BY sort_order ASC, created_at DESC")
    tasks = cursor.fetchall()

    names = _usernames_map(cursor)

    task_ids = [t["id"] for t in tasks]
    subtasks_by_task = {tid: [] for tid in task_ids}
    attachments_by_task = {tid: [] for tid in task_ids}

    if task_ids:
        fmt = ",".join(["%s"] * len(task_ids))
        cursor.execute(f"SELECT * FROM subtasks WHERE task_id IN ({fmt}) ORDER BY sort_order ASC, id ASC", task_ids)
        for s in cursor.fetchall():
            subtasks_by_task.setdefault(s["task_id"], []).append(s)

        cursor.execute(f"SELECT * FROM attachments WHERE task_id IN ({fmt}) ORDER BY uploaded_at ASC", task_ids)
        for a in cursor.fetchall():
            a["uploaded_at"] = str(a["uploaded_at"])
            attachments_by_task.setdefault(a["task_id"], []).append(a)

    cursor.close()
    conn.close()

    for t in tasks:
        t["created_by_name"] = names.get(t.get("created_by"))
        t["assigned_to_name"] = names.get(t.get("assigned_to"))
        t["subtasks"] = subtasks_by_task.get(t["id"], [])
        t["attachments"] = attachments_by_task.get(t["id"], [])

    return jsonify(_serialize(tasks))


@app.route('/api/tasks', methods=['POST'])
@login_required
def add_task():
    data = request.get_json(force=True)
    title = (data.get('title') or '').strip()
    priority = _clean_priority(data.get('priority', 'medium'))
    category = (data.get('category') or 'General').strip() or 'General'
    due_date = data.get('due_date') or None
    notes = (data.get('notes') or '').strip() or None
    repeat_type = _clean_repeat(data.get('repeat_type', 'none'))
    assigned_to = data.get('assigned_to') or None

    if not title:
        return jsonify({"error": "Title cannot be empty"}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM tasks")
    next_order = cursor.fetchone()[0]
    cursor.execute(
        """INSERT INTO tasks (title, done, priority, category, due_date, notes,
           created_by, assigned_to, repeat_type, sort_order)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
        (title, False, priority, category, due_date, notes,
         session["user_id"], assigned_to, repeat_type, next_order)
    )
    conn.commit()
    new_id = cursor.lastrowid
    cursor.close()
    conn.close()
    return jsonify({
        "id": new_id, "title": title, "done": False, "priority": priority,
        "category": category, "due_date": due_date, "notes": notes,
        "repeat_type": repeat_type, "assigned_to": assigned_to
    }), 201


@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
@login_required
def toggle_task(task_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM tasks WHERE id = %s", (task_id,))
    task = cursor.fetchone()
    if task is None:
        cursor.close()
        conn.close()
        return jsonify({"error": "Task not found"}), 404

    new_status = not task['done']
    if new_status:
        cursor.execute("UPDATE tasks SET done = %s, completed_at = NOW() WHERE id = %s", (new_status, task_id))
    else:
        cursor.execute("UPDATE tasks SET done = %s, completed_at = NULL WHERE id = %s", (new_status, task_id))
    conn.commit()

    spawned = None
    if new_status and task['repeat_type'] and task['repeat_type'] != 'none' and task['due_date']:
        next_date = _next_due_date(task['due_date'], task['repeat_type'])
        if next_date:
            cursor.execute("SELECT COALESCE(MAX(sort_order), 0) + 1 AS n FROM tasks")
            next_order = cursor.fetchone()["n"]
            cursor.execute(
                """INSERT INTO tasks (title, done, priority, category, due_date, notes,
                   created_by, assigned_to, repeat_type, sort_order)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                (task['title'], False, task['priority'], task['category'], next_date, task['notes'],
                 task['created_by'], task['assigned_to'], task['repeat_type'], next_order)
            )
            conn.commit()
            spawned = cursor.lastrowid

    cursor.close()
    conn.close()
    return jsonify({"id": task_id, "title": task['title'], "done": new_status, "spawned_task_id": spawned})


@app.route('/api/tasks/<int:task_id>', methods=['PATCH'])
@login_required
def edit_task(task_id):
    data = request.get_json(force=True)
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM tasks WHERE id = %s", (task_id,))
    task = cursor.fetchone()
    if task is None:
        cursor.close()
        conn.close()
        return jsonify({"error": "Task not found"}), 404

    new_title = (data.get('title', task['title']) or '').strip()
    new_priority = data.get('priority', task['priority'])
    new_priority = new_priority if new_priority in ('low', 'medium', 'high') else task['priority']
    new_category = (data.get('category', task['category']) or 'General').strip() or 'General'
    new_due_date = data.get('due_date', task['due_date'])
    if new_due_date == '':
        new_due_date = None
    new_notes = data.get('notes', task['notes'])
    if new_notes == '':
        new_notes = None
    new_repeat = data.get('repeat_type', task['repeat_type'] or 'none')
    new_repeat = _clean_repeat(new_repeat)
    new_assigned = data.get('assigned_to', task['assigned_to'])
    if new_assigned == '':
        new_assigned = None

    if not new_title:
        cursor.close()
        conn.close()
        return jsonify({"error": "Title cannot be empty"}), 400

    cursor.execute(
        """UPDATE tasks SET title=%s, priority=%s, category=%s, due_date=%s, notes=%s,
           repeat_type=%s, assigned_to=%s WHERE id=%s""",
        (new_title, new_priority, new_category, new_due_date, new_notes,
         new_repeat, new_assigned, task_id)
    )
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({
        "id": task_id, "title": new_title, "priority": new_priority, "done": task['done'],
        "category": new_category, "due_date": str(new_due_date) if new_due_date else None,
        "notes": new_notes, "repeat_type": new_repeat, "assigned_to": new_assigned
    })


@app.route('/api/tasks/reorder', methods=['PATCH'])
@login_required
def reorder_tasks():
    data = request.get_json(force=True)
    ordered_ids = data.get('order', [])
    conn = get_db_connection()
    cursor = conn.cursor()
    for index, task_id in enumerate(ordered_ids):
        cursor.execute("UPDATE tasks SET sort_order = %s WHERE id = %s", (index, task_id))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"message": "Order updated"})


@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
@login_required
def delete_task(task_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM tasks WHERE id = %s", (task_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"message": "Task deleted"}), 200


@app.route('/api/tasks/clear-completed', methods=['DELETE'])
@login_required
def clear_completed():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM tasks WHERE done = TRUE")
    conn.commit()
    deleted = cursor.rowcount
    cursor.close()
    conn.close()
    return jsonify({"message": f"{deleted} completed tasks deleted"}), 200


# ---------------------------------------------------------------- subtasks API

@app.route('/api/tasks/<int:task_id>/subtasks', methods=['POST'])
@login_required
def add_subtask(task_id):
    data = request.get_json(force=True)
    title = (data.get('title') or '').strip()
    if not title:
        return jsonify({"error": "Subtask title cannot be empty"}), 400
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT COALESCE(MAX(sort_order), 0) + 1 AS n FROM subtasks WHERE task_id = %s", (task_id,))
    next_order = cursor.fetchone()["n"]
    cursor.execute(
        "INSERT INTO subtasks (task_id, title, sort_order) VALUES (%s, %s, %s)",
        (task_id, title, next_order)
    )
    conn.commit()
    new_id = cursor.lastrowid
    cursor.close()
    conn.close()
    return jsonify({"id": new_id, "task_id": task_id, "title": title, "done": False}), 201


@app.route('/api/subtasks/<int:subtask_id>', methods=['PUT'])
@login_required
def toggle_subtask(subtask_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM subtasks WHERE id = %s", (subtask_id,))
    sub = cursor.fetchone()
    if sub is None:
        cursor.close()
        conn.close()
        return jsonify({"error": "Subtask not found"}), 404
    new_status = not sub['done']
    cursor.execute("UPDATE subtasks SET done = %s WHERE id = %s", (new_status, subtask_id))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"id": subtask_id, "done": new_status})


@app.route('/api/subtasks/<int:subtask_id>', methods=['DELETE'])
@login_required
def delete_subtask(subtask_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM subtasks WHERE id = %s", (subtask_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"message": "Subtask deleted"}), 200


# ---------------------------------------------------------------- attachments API

ALLOWED_EXT = {"png", "jpg", "jpeg", "gif", "pdf", "doc", "docx", "xls", "xlsx", "txt", "zip"}


def _allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


@app.route('/api/tasks/<int:task_id>/attachments', methods=['POST'])
@login_required
def upload_attachment(task_id):
    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400
    file = request.files['file']
    if file.filename == '' or not _allowed_file(file.filename):
        return jsonify({"error": "Unsupported or missing file"}), 400

    original_name = secure_filename(file.filename)
    stored_name = f"{task_id}_{uuid.uuid4().hex[:10]}_{original_name}"
    file.save(os.path.join(UPLOAD_FOLDER, stored_name))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO attachments (task_id, original_name, stored_name) VALUES (%s, %s, %s)",
        (task_id, original_name, stored_name)
    )
    conn.commit()
    new_id = cursor.lastrowid
    cursor.close()
    conn.close()
    return jsonify({"id": new_id, "task_id": task_id, "original_name": original_name,
                     "stored_name": stored_name}), 201


@app.route('/api/attachments/<int:attachment_id>', methods=['DELETE'])
@login_required
def delete_attachment(attachment_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM attachments WHERE id = %s", (attachment_id,))
    a = cursor.fetchone()
    if a:
        cursor.execute("DELETE FROM attachments WHERE id = %s", (attachment_id,))
        conn.commit()
        try:
            os.remove(os.path.join(UPLOAD_FOLDER, a["stored_name"]))
        except OSError:
            pass
    cursor.close()
    conn.close()
    return jsonify({"message": "Attachment deleted"}), 200


@app.route('/uploads/<path:filename>')
@login_required
def get_upload(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)


# ---------------------------------------------------------------- stats / streak API

@app.route('/api/stats', methods=['GET'])
@login_required
def get_stats():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT DISTINCT DATE(completed_at) AS d FROM tasks WHERE completed_at IS NOT NULL ORDER BY d DESC")
    completed_dates = {row["d"] for row in cursor.fetchall()}
    cursor.close()
    conn.close()

    streak = 0
    cursor_date = date.today()
    if cursor_date not in completed_dates:
        cursor_date = cursor_date - timedelta(days=1)
    while cursor_date in completed_dates:
        streak += 1
        cursor_date -= timedelta(days=1)

    return jsonify({
        "streak": streak,
        "days_completed": len(completed_dates)
    })


if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000, host='0.0.0.0')
