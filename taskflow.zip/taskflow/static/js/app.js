let allTasks = [];
let editingId = null;
let notesOpenId = null;
let subtasksOpenId = null;
let attachmentsOpenId = null;
let priorityFilter = 'all';
let categoryFilter = 'all';
let assigneeFilter = 'all';
let currentView = 'today';
let calendarCursor = new Date();
let draggedId = null;
const priorityRank = { high: 3, medium: 2, low: 1 };
const notifiedTaskIds = new Set();

const ICONS = {
  edit: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>`,
  trash: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6h16z"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>`,
  note: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3v4a1 1 0 0 0 1 1h4M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2Z"/></svg>`,
  subtask: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`,
  attach: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>`,
  drag: `<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/><circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></svg>`
};

const CAT_COLORS = ['#3D5A80', '#B8791A', '#4C7A5A', '#8B5FBF', '#C1440E', '#2E86AB', '#A64AC9'];
function colorForCategory(name) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return CAT_COLORS[Math.abs(hash) % CAT_COLORS.length];
}

function todayStr() {
  const d = new Date(); d.setHours(0,0,0,0);
  return d.toISOString().slice(0,10);
}
function daysDiff(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  const now = new Date(); now.setHours(0,0,0,0);
  return Math.round((d - now) / 86400000);
}
function dueLabel(dateStr) {
  const diff = daysDiff(dateStr);
  if (diff < 0) return { text: `${Math.abs(diff)}d overdue`, cls: 'overdue' };
  if (diff === 0) return { text: 'Today', cls: 'today' };
  if (diff === 1) return { text: 'Tomorrow', cls: '' };
  return { text: new Date(dateStr + 'T00:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric' }), cls: '' };
}

function setDateHeader() {
  const now = new Date();
  document.getElementById('date-day').textContent = now.toLocaleDateString(undefined, { weekday: 'long' }) + ',';
  document.getElementById('date-rest').textContent = ' ' + now.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' });
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str == null ? '' : str;
  return d.innerHTML;
}

function showToast(message, undoFn) {
  const wrap = document.getElementById('toast-wrap');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<span>${escapeHtml(message)}</span>`;
  if (undoFn) {
    const btn = document.createElement('button');
    btn.textContent = 'UNDO';
    btn.addEventListener('click', () => { undoFn(); toast.remove(); });
    toast.appendChild(btn);
  }
  wrap.appendChild(toast);
  setTimeout(() => toast.remove(), 4500);
}

/* ---------------------------------------------------------------- theme */

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.getElementById('theme-label').textContent = theme === 'dark' ? 'Light mode' : 'Dark mode';
  document.getElementById('theme-icon').textContent = theme === 'dark' ? '☀️' : '🌙';
}
function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  localStorage.setItem('taskflow-theme', next);
  applyTheme(next);
}
(function initTheme() {
  const saved = localStorage.getItem('taskflow-theme') ||
    (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  applyTheme(saved);
})();

/* ---------------------------------------------------------------- data loading */

async function loadTasks() {
  try {
    const response = await fetch('/api/tasks');
    if (response.status === 401) { window.location.href = '/login'; return; }
    allTasks = await response.json();
  } catch (err) {
    console.error('Could not reach the server / database:', err);
  }
  renderSidebarCounts();
  renderCategories();
  render();
  checkDueReminders();
}

async function loadStats() {
  try {
    const res = await fetch('/api/stats');
    if (!res.ok) return;
    const stats = await res.json();
    document.getElementById('streak-num').textContent = stats.streak;
  } catch (err) { /* non-critical */ }
}

/* ---------------------------------------------------------------- views/filters */

function setView(view) {
  currentView = view;
  document.querySelectorAll('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.view === view));
  const titles = {
    today: ['Today', 'Everything due today, plus anything without a date'],
    upcoming: ['Upcoming', 'Tasks scheduled for a future date'],
    calendar: ['Calendar', 'Your tasks laid out across the month'],
    all: ['All Tasks', 'Every active task, regardless of date'],
    mine: ['Assigned to me', 'Tasks assigned to you'],
    completed: ['Completed', 'Tasks you have finished']
  };
  document.getElementById('view-title').textContent = titles[view][0];
  document.getElementById('view-sub').textContent = titles[view][1];

  const isCalendar = view === 'calendar';
  document.getElementById('list-view-controls').style.display = isCalendar ? 'none' : 'block';
  document.getElementById('task-list').style.display = isCalendar ? 'none' : 'flex';
  document.getElementById('calendar-view').style.display = isCalendar ? 'block' : 'none';
  render();
}

function setPriorityFilter(p) {
  priorityFilter = p;
  document.querySelectorAll('.pf-chip').forEach(chip => chip.classList.toggle('active', chip.dataset.p === p));
  render();
}

function setCategoryFilter(cat) {
  categoryFilter = cat;
  render();
  renderCategories();
}

function setAssigneeFilter(val) {
  assigneeFilter = val;
  render();
}

function renderSidebarCounts() {
  const active = allTasks.filter(t => !t.done);
  const today = active.filter(t => !t.due_date || daysDiff(t.due_date) <= 0);
  const upcoming = active.filter(t => t.due_date && daysDiff(t.due_date) > 0);
  const mine = active.filter(t => String(t.assigned_to) === String(window.CURRENT_USER_ID));
  document.getElementById('count-today').textContent = today.length;
  document.getElementById('count-upcoming').textContent = upcoming.length;
  document.getElementById('count-all').textContent = active.length;
  document.getElementById('count-mine').textContent = mine.length;
  document.getElementById('count-completed').textContent = allTasks.filter(t => t.done).length;
}

function renderCategories() {
  const counts = {};
  allTasks.filter(t => !t.done).forEach(t => {
    const c = t.category || 'General';
    counts[c] = (counts[c] || 0) + 1;
  });
  const list = document.getElementById('category-list');
  list.innerHTML = '';

  const allItem = document.createElement('div');
  allItem.className = 'cat-item' + (categoryFilter === 'all' ? ' active' : '');
  allItem.innerHTML = `<span class="cat-dot" style="background:#8b8578"></span><span class="cat-name">All categories</span>`;
  allItem.addEventListener('click', () => setCategoryFilter('all'));
  list.appendChild(allItem);

  Object.keys(counts).sort().forEach(cat => {
    const item = document.createElement('div');
    item.className = 'cat-item' + (categoryFilter === cat ? ' active' : '');
    item.innerHTML = `<span class="cat-dot" style="background:${colorForCategory(cat)}"></span><span class="cat-name">${escapeHtml(cat)}</span><span class="cat-count">${counts[cat]}</span>`;
    item.addEventListener('click', () => setCategoryFilter(cat));
    list.appendChild(item);
  });
}

function getViewTasks() {
  let tasks = allTasks;
  if (currentView === 'completed') {
    tasks = tasks.filter(t => t.done);
  } else if (currentView === 'mine') {
    tasks = tasks.filter(t => !t.done && String(t.assigned_to) === String(window.CURRENT_USER_ID));
  } else {
    tasks = tasks.filter(t => !t.done);
    if (currentView === 'today') tasks = tasks.filter(t => !t.due_date || daysDiff(t.due_date) <= 0);
    if (currentView === 'upcoming') tasks = tasks.filter(t => t.due_date && daysDiff(t.due_date) > 0);
  }
  return tasks;
}

function getFilteredSorted() {
  const query = document.getElementById('search-box').value.trim().toLowerCase();
  const sortBy = document.getElementById('sort-select').value;

  let tasks = getViewTasks().filter(t => t.title.toLowerCase().includes(query));
  if (priorityFilter !== 'all') tasks = tasks.filter(t => (t.priority || 'medium') === priorityFilter);
  if (categoryFilter !== 'all') tasks = tasks.filter(t => (t.category || 'General') === categoryFilter);
  if (assigneeFilter !== 'all') tasks = tasks.filter(t => String(t.assigned_to) === String(assigneeFilter));

  if (sortBy === 'priority') {
    tasks = tasks.slice().sort((a, b) => (priorityRank[b.priority] || 0) - (priorityRank[a.priority] || 0));
  } else if (sortBy === 'az') {
    tasks = tasks.slice().sort((a, b) => a.title.localeCompare(b.title));
  } else if (sortBy === 'due') {
    tasks = tasks.slice().sort((a, b) => {
      if (!a.due_date && !b.due_date) return 0;
      if (!a.due_date) return 1;
      if (!b.due_date) return -1;
      return new Date(a.due_date) - new Date(b.due_date);
    });
  } else {
    tasks = tasks.slice().sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0) || (b.id || 0) - (a.id || 0));
  }
  return tasks;
}

function render() {
  if (currentView === 'calendar') { renderCalendar(); updateProgress(); return; }

  const tasks = getFilteredSorted();
  const container = document.getElementById('task-list');
  container.innerHTML = '';

  if (tasks.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    const msg = currentView === 'completed' ? 'Nothing completed yet.' : 'Nothing here — add a task below.';
    empty.innerHTML = `<span class="empty-big">All clear</span>${msg}`;
    container.appendChild(empty);
  } else {
    tasks.forEach(task => container.appendChild(buildTaskElement(task)));
  }

  updateProgress();
}

function updateProgress() {
  const total = allTasks.length;
  const completed = allTasks.filter(t => t.done).length;
  const percent = total === 0 ? 0 : Math.round((completed / total) * 100);
  document.getElementById('progress-fill').style.width = `${percent}%`;
  document.getElementById('progress-pct').textContent = `${percent}% complete`;
}

/* ---------------------------------------------------------------- task card */

function buildTaskElement(task) {
  const isEditing = editingId === task.id;
  const priority = task.priority || 'medium';
  const category = task.category || 'General';
  const subtasks = task.subtasks || [];
  const attachments = task.attachments || [];
  const doneSubtasks = subtasks.filter(s => s.done).length;

  const wrapper = document.createElement('div');
  wrapper.className = `task priority-${priority}${task.done ? ' done' : ''}`;
  wrapper.draggable = !isEditing;
  wrapper.dataset.id = task.id;

  wrapper.addEventListener('dragstart', () => { draggedId = task.id; wrapper.classList.add('dragging'); });
  wrapper.addEventListener('dragend', () => { wrapper.classList.remove('dragging'); wrapper.classList.remove('drag-over'); });
  wrapper.addEventListener('dragover', (e) => { e.preventDefault(); wrapper.classList.add('drag-over'); });
  wrapper.addEventListener('dragleave', () => wrapper.classList.remove('drag-over'));
  wrapper.addEventListener('drop', (e) => {
    e.preventDefault();
    wrapper.classList.remove('drag-over');
    if (draggedId && draggedId !== task.id) reorderDrop(draggedId, task.id);
  });

  const row = document.createElement('div');
  row.className = 'task-row';

  const left = document.createElement('div');
  left.className = 'task-left';

  const handle = document.createElement('span');
  handle.className = 'drag-handle';
  handle.innerHTML = ICONS.drag;
  handle.title = 'Drag to reorder';
  left.appendChild(handle);

  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.checked = task.done;
  checkbox.disabled = isEditing;
  checkbox.addEventListener('change', () => toggleTask(task.id));
  left.appendChild(checkbox);

  const mainBlock = document.createElement('div');
  mainBlock.className = 'task-main';

  if (isEditing) {
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'edit-input';
    input.value = task.title;
    input.id = `edit-input-${task.id}`;
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveEdit(task.id); if (e.key === 'Escape') cancelEdit(); });
    mainBlock.appendChild(input);

    const metaRow = document.createElement('div');
    metaRow.className = 'edit-meta-row';
    const assignOptions = (window.ALL_USERS || []).map(u =>
      `<option value="${u.id}" ${String(task.assigned_to) === String(u.id) ? 'selected' : ''}>${escapeHtml(u.username)}</option>`
    ).join('');
    metaRow.innerHTML = `
      <input type="text" id="edit-cat-${task.id}" value="${escapeHtml(category)}" placeholder="Category">
      <input type="date" id="edit-due-${task.id}" value="${task.due_date || ''}">
      <select id="edit-repeat-${task.id}">
        <option value="none" ${task.repeat_type === 'none' || !task.repeat_type ? 'selected' : ''}>Does not repeat</option>
        <option value="daily" ${task.repeat_type === 'daily' ? 'selected' : ''}>Daily</option>
        <option value="weekly" ${task.repeat_type === 'weekly' ? 'selected' : ''}>Weekly</option>
        <option value="monthly" ${task.repeat_type === 'monthly' ? 'selected' : ''}>Monthly</option>
      </select>
      <select id="edit-assign-${task.id}">
        <option value="">Unassigned</option>
        ${assignOptions}
      </select>
    `;
    mainBlock.appendChild(metaRow);
  } else {
    const titleSpan = document.createElement('span');
    titleSpan.className = 'task-title';
    titleSpan.textContent = task.title;
    mainBlock.appendChild(titleSpan);

    const meta = document.createElement('div');
    meta.className = 'task-meta';

    const flag = document.createElement('span');
    flag.className = `flag flag-${priority}`;
    flag.textContent = priority.charAt(0).toUpperCase() + priority.slice(1);
    meta.appendChild(flag);

    // Only show the category chip for a category the user actually chose —
    // no point stamping "General" on every single task.
    if (category !== 'General') {
      const catChip = document.createElement('span');
      catChip.className = 'tag-chip';
      catChip.style.background = colorForCategory(category) + '22';
      catChip.style.color = colorForCategory(category);
      catChip.textContent = category;
      meta.appendChild(catChip);
    }

    if (task.repeat_type && task.repeat_type !== 'none') {
      const repChip = document.createElement('span');
      repChip.className = 'repeat-chip';
      repChip.textContent = '↻ ' + task.repeat_type;
      meta.appendChild(repChip);
    }

    if (task.assigned_to_name) {
      const assignChip = document.createElement('span');
      assignChip.className = 'assign-chip';
      assignChip.textContent = '@' + task.assigned_to_name;
      meta.appendChild(assignChip);
    }

    mainBlock.appendChild(meta);

    // Due date gets its own line below, and only appears for tasks that
    // actually have one — instead of squeezed in next to priority/category.
    if (task.due_date) {
      const dueRow = document.createElement('div');
      dueRow.className = 'task-due-row';
      const info = dueLabel(task.due_date);
      const dueChip = document.createElement('span');
      dueChip.className = `due-chip ${info.cls}`;
      dueChip.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg><span>${info.text}</span>`;
      dueRow.appendChild(dueChip);
      if (subtasks.length) {
        const stProgress = document.createElement('span');
        stProgress.className = 'subtask-progress';
        stProgress.textContent = `${doneSubtasks}/${subtasks.length} subtasks`;
        dueRow.appendChild(stProgress);
      }
      mainBlock.appendChild(dueRow);
    } else if (subtasks.length) {
      const stRow = document.createElement('div');
      stRow.className = 'task-due-row';
      const stProgress = document.createElement('span');
      stProgress.className = 'subtask-progress';
      stProgress.textContent = `${doneSubtasks}/${subtasks.length} subtasks`;
      stRow.appendChild(stProgress);
      mainBlock.appendChild(stRow);
    }
  }
  left.appendChild(mainBlock);
  row.appendChild(left);

  const actions = document.createElement('div');
  actions.className = 'task-actions';

  if (isEditing) {
    const saveBtn = document.createElement('button');
    saveBtn.className = 'icon-btn save-btn'; saveBtn.innerHTML = ICONS.check; saveBtn.type = 'button'; saveBtn.title = 'Save';
    saveBtn.addEventListener('click', () => saveEdit(task.id));
    actions.appendChild(saveBtn);

    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'text-action cancel-btn'; cancelBtn.textContent = 'Cancel'; cancelBtn.type = 'button';
    cancelBtn.addEventListener('click', cancelEdit);
    actions.appendChild(cancelBtn);
  } else {
    const subBtn = document.createElement('button');
    subBtn.className = 'icon-btn subtask-btn' + (subtasks.length ? ' has-subtasks' : '');
    subBtn.innerHTML = ICONS.subtask; subBtn.type = 'button'; subBtn.title = 'Subtasks';
    subBtn.addEventListener('click', () => toggleSubtasksPanel(task.id));
    actions.appendChild(subBtn);

    const attachBtn = document.createElement('button');
    attachBtn.className = 'icon-btn attach-btn' + (attachments.length ? ' has-attachments' : '');
    attachBtn.innerHTML = ICONS.attach; attachBtn.type = 'button'; attachBtn.title = 'Attachments';
    attachBtn.addEventListener('click', () => toggleAttachmentsPanel(task.id));
    actions.appendChild(attachBtn);

    const notesBtn = document.createElement('button');
    notesBtn.className = 'icon-btn notes-btn' + (task.notes ? ' has-notes' : '');
    notesBtn.innerHTML = ICONS.note; notesBtn.type = 'button'; notesBtn.title = 'Notes';
    notesBtn.addEventListener('click', () => toggleNotes(task.id));
    actions.appendChild(notesBtn);

    const editBtn = document.createElement('button');
    editBtn.className = 'icon-btn'; editBtn.innerHTML = ICONS.edit; editBtn.type = 'button'; editBtn.title = 'Edit';
    editBtn.addEventListener('click', () => startEdit(task.id));
    actions.appendChild(editBtn);

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'icon-btn delete-btn'; deleteBtn.innerHTML = ICONS.trash; deleteBtn.type = 'button'; deleteBtn.title = 'Delete';
    deleteBtn.addEventListener('click', () => deleteTask(task));
    actions.appendChild(deleteBtn);
  }
  row.appendChild(actions);
  wrapper.appendChild(row);

  const notesPanel = document.createElement('div');
  notesPanel.className = 'notes-panel' + (notesOpenId === task.id ? ' open' : '');
  notesPanel.innerHTML = `
    <textarea id="notes-text-${task.id}" placeholder="Add a note...">${task.notes ? escapeHtml(task.notes) : ''}</textarea>
    <br><button class="notes-save" type="button" onclick="saveNotes(${task.id})">Save note</button>
  `;
  wrapper.appendChild(notesPanel);

  const subtasksPanel = document.createElement('div');
  subtasksPanel.className = 'subtasks-panel' + (subtasksOpenId === task.id ? ' open' : '');
  subtasksPanel.innerHTML = buildSubtasksPanelHtml(task);
  wrapper.appendChild(subtasksPanel);

  const attachmentsPanel = document.createElement('div');
  attachmentsPanel.className = 'attachments-panel' + (attachmentsOpenId === task.id ? ' open' : '');
  attachmentsPanel.innerHTML = buildAttachmentsPanelHtml(task);
  wrapper.appendChild(attachmentsPanel);

  return wrapper;
}

async function reorderDrop(fromId, toId) {
  const visible = getFilteredSorted().map(t => t.id);
  const fromIdx = visible.indexOf(fromId);
  const toIdx = visible.indexOf(toId);
  if (fromIdx === -1 || toIdx === -1) return;
  visible.splice(toIdx, 0, visible.splice(fromIdx, 1)[0]);

  await fetch('/api/tasks/reorder', {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ order: visible })
  });
  draggedId = null;
  loadTasks();
}

/* ---------------------------------------------------------------- subtasks */

function buildSubtasksPanelHtml(task) {
  const subtasks = task.subtasks || [];
  let rows = subtasks.map(s => `
    <div class="subtask-row${s.done ? ' done' : ''}">
      <input type="checkbox" ${s.done ? 'checked' : ''} onchange="toggleSubtask(${s.id})">
      <span class="st-title">${escapeHtml(s.title)}</span>
      <button class="icon-btn" type="button" title="Delete" onclick="deleteSubtask(${s.id})">${ICONS.trash}</button>
    </div>
  `).join('');
  return `
    ${rows}
    <div class="subtask-add-row">
      <input type="text" id="new-subtask-${task.id}" placeholder="Add a subtask..." onkeydown="if(event.key==='Enter') addSubtask(${task.id})">
      <button class="text-action" type="button" style="background:var(--accent); color:#fff;" onclick="addSubtask(${task.id})">Add</button>
    </div>
  `;
}

function toggleSubtasksPanel(id) {
  subtasksOpenId = subtasksOpenId === id ? null : id;
  render();
}

async function addSubtask(taskId) {
  const input = document.getElementById(`new-subtask-${taskId}`);
  const title = input.value.trim();
  if (!title) return;
  await fetch(`/api/tasks/${taskId}/subtasks`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title })
  });
  loadTasks();
}

async function toggleSubtask(id) {
  await fetch(`/api/subtasks/${id}`, { method: 'PUT' });
  loadTasks();
}

async function deleteSubtask(id) {
  await fetch(`/api/subtasks/${id}`, { method: 'DELETE' });
  loadTasks();
}

/* ---------------------------------------------------------------- attachments */

function buildAttachmentsPanelHtml(task) {
  const attachments = task.attachments || [];
  let rows = attachments.map(a => `
    <div class="attach-item">
      ${ICONS.attach}
      <a href="/uploads/${encodeURIComponent(a.stored_name)}" target="_blank" rel="noopener">${escapeHtml(a.original_name)}</a>
      <button class="icon-btn" type="button" title="Delete" onclick="deleteAttachment(${a.id})">${ICONS.trash}</button>
    </div>
  `).join('');
  return `
    ${rows}
    <div class="attach-upload-row">
      <input type="file" id="new-attach-${task.id}">
      <button class="text-action" type="button" style="background:var(--accent); color:#fff;" onclick="uploadAttachment(${task.id})">Upload</button>
    </div>
  `;
}

function toggleAttachmentsPanel(id) {
  attachmentsOpenId = attachmentsOpenId === id ? null : id;
  render();
}

async function uploadAttachment(taskId) {
  const input = document.getElementById(`new-attach-${taskId}`);
  if (!input.files.length) return;
  const formData = new FormData();
  formData.append('file', input.files[0]);
  const res = await fetch(`/api/tasks/${taskId}/attachments`, { method: 'POST', body: formData });
  if (!res.ok) { showToast('Could not upload that file'); return; }
  showToast('Attachment uploaded');
  loadTasks();
}

async function deleteAttachment(id) {
  await fetch(`/api/attachments/${id}`, { method: 'DELETE' });
  loadTasks();
}

/* ---------------------------------------------------------------- notes */

function toggleNotes(id) {
  notesOpenId = notesOpenId === id ? null : id;
  render();
}

async function saveNotes(id) {
  const textarea = document.getElementById(`notes-text-${id}`);
  const notes = textarea.value.trim();
  await fetch(`/api/tasks/${id}`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ notes })
  });
  showToast('Note saved');
  loadTasks();
}

/* ---------------------------------------------------------------- add / edit / delete */

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('add-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('title').value;
    const priority = document.querySelector('input[name="priority"]:checked').value;
    const category = document.getElementById('category').value.trim() || 'General';
    const due_date = document.getElementById('due-date').value || null;
    const repeat_type = document.getElementById('repeat-type').value;
    const assigned_to = document.getElementById('assign-to').value || null;

    await fetch('/api/tasks', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, priority, category, due_date, repeat_type, assigned_to })
    });

    e.target.reset();
    document.getElementById('p-medium').checked = true;
    document.getElementById('repeat-type').value = 'none';
    showToast('Task added');
    loadTasks();
  });

  document.getElementById('search-box').addEventListener('input', render);
  document.getElementById('sort-select').addEventListener('change', render);
  document.getElementById('assignee-filter').addEventListener('change', (e) => setAssigneeFilter(e.target.value));

  const initials = (window.CURRENT_USERNAME || '?').slice(0, 2).toUpperCase();
  document.getElementById('user-avatar').textContent = initials;

  setDateHeader();
  registerServiceWorker();
  loadTasks();
  loadStats();
});

async function toggleTask(id) {
  const res = await fetch(`/api/tasks/${id}`, { method: 'PUT' });
  const data = await res.json();
  if (data.spawned_task_id) showToast('Task completed — next occurrence added');
  loadTasks();
  loadStats();
}

async function deleteTask(task) {
  await fetch(`/api/tasks/${task.id}`, { method: 'DELETE' });
  showToast('Task deleted', async () => {
    await fetch('/api/tasks', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: task.title, priority: task.priority, category: task.category, due_date: task.due_date })
    });
    loadTasks();
  });
  loadTasks();
}

async function clearCompleted() {
  if (!confirm('Delete all completed tasks?')) return;
  await fetch('/api/tasks/clear-completed', { method: 'DELETE' });
  showToast('Completed tasks cleared');
  loadTasks();
}

function startEdit(id) {
  editingId = id;
  render();
  setTimeout(() => {
    const input = document.getElementById(`edit-input-${id}`);
    if (input) { input.focus(); input.select(); }
  }, 0);
}

function cancelEdit() { editingId = null; render(); }

async function saveEdit(id) {
  const input = document.getElementById(`edit-input-${id}`);
  const newTitle = input.value.trim();
  if (!newTitle) return;
  const category = document.getElementById(`edit-cat-${id}`).value.trim() || 'General';
  const due_date = document.getElementById(`edit-due-${id}`).value || null;
  const repeat_type = document.getElementById(`edit-repeat-${id}`).value;
  const assigned_to = document.getElementById(`edit-assign-${id}`).value || '';

  await fetch(`/api/tasks/${id}`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: newTitle, category, due_date, repeat_type, assigned_to })
  });

  editingId = null;
  showToast('Task updated');
  loadTasks();
}

/* ---------------------------------------------------------------- calendar view */

function renderCalendar() {
  const container = document.getElementById('calendar-view');
  const year = calendarCursor.getFullYear();
  const month = calendarCursor.getMonth();
  const monthLabel = calendarCursor.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

  const firstOfMonth = new Date(year, month, 1);
  const startWeekday = firstOfMonth.getDay();
  const gridStart = new Date(year, month, 1 - startWeekday);

  const tasksByDate = {};
  allTasks.filter(t => !t.done && t.due_date).forEach(t => {
    (tasksByDate[t.due_date] = tasksByDate[t.due_date] || []).push(t);
  });

  const dows = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  let cellsHtml = '';
  for (let i = 0; i < 42; i++) {
    const cellDate = new Date(gridStart);
    cellDate.setDate(gridStart.getDate() + i);
    const dateStr = cellDate.toISOString().slice(0, 10);
    const isOtherMonth = cellDate.getMonth() !== month;
    const isToday = dateStr === todayStr();
    const dayTasks = (tasksByDate[dateStr] || []);
    const shown = dayTasks.slice(0, 3);
    const chips = shown.map(t => `<div class="cal-task-chip p-${t.priority || 'medium'}" title="${escapeHtml(t.title)}">${escapeHtml(t.title)}</div>`).join('');
    const more = dayTasks.length > 3 ? `<div class="cal-more">+${dayTasks.length - 3} more</div>` : '';
    cellsHtml += `
      <div class="cal-cell${isOtherMonth ? ' other-month' : ''}${isToday ? ' is-today' : ''}" onclick="quickSetDueDate('${dateStr}')">
        <div class="cal-date">${cellDate.getDate()}</div>
        ${chips}${more}
      </div>
    `;
  }

  container.innerHTML = `
    <div class="calendar-nav">
      <button onclick="shiftMonth(-1)">‹</button>
      <span class="cal-month-label">${monthLabel}</span>
      <button onclick="shiftMonth(1)">›</button>
    </div>
    <div class="calendar-grid">
      ${dows.map(d => `<div class="cal-dow">${d}</div>`).join('')}
      ${cellsHtml}
    </div>
  `;
}

function shiftMonth(delta) {
  calendarCursor = new Date(calendarCursor.getFullYear(), calendarCursor.getMonth() + delta, 1);
  renderCalendar();
}

function quickSetDueDate(dateStr) {
  document.getElementById('due-date').value = dateStr;
  document.getElementById('title').focus();
  showToast(`New task due date set to ${dateStr}`);
}

/* ---------------------------------------------------------------- reminders */

function requestNotificationPermission() {
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }
}

function checkDueReminders() {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const dueTodayOrOverdue = allTasks.filter(t =>
    !t.done && t.due_date && daysDiff(t.due_date) <= 0 && !notifiedTaskIds.has(t.id)
  );
  dueTodayOrOverdue.forEach(t => {
    notifiedTaskIds.add(t.id);
    const label = daysDiff(t.due_date) < 0 ? 'Overdue' : 'Due today';
    try {
      new Notification(`${label}: ${t.title}`, {
        body: t.category && t.category !== 'General' ? t.category : 'TaskFlow reminder',
        icon: '/static/icons/icon-192.png'
      });
    } catch (err) { /* ignore if browser blocks it */ }
  });
}
requestNotificationPermission();

/* ---------------------------------------------------------------- PWA */

function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js').catch(() => {});
  }
}
